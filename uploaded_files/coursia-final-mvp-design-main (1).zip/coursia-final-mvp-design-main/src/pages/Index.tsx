import IntakeWizard from "@/components/IntakeWizard";

const Index = () => {
  return <IntakeWizard />;
};

export default Index;
